// $("#sign-in-btn").click(function(e){
//     e.preventDefault();
//     var $loginForm = $('#login-form');
//     console.log($().validate())
//     if($loginForm.length){
//         $loginForm.validate({
//             rules: {
//                 email: {
//                     required: true,
//                 }
//             },
//             messages: {
//                 email: {
//                     required: 'email needs a value',
//                 }
//             }

//         });//form
//     }
// });