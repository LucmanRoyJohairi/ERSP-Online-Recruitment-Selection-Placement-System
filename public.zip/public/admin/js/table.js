$(document).ready(function() {
    $('#user-table').DataTable();
} );