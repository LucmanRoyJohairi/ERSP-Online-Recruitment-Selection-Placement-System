$('#dashboard').click(function(e){
    window.location.href = "/admin/dashboard";
    return false;
   });
$('#poolOfApplicants').click(function(e){
window.location.href = "/admin/dashboard/applicants";
return false;

});
$('#joblist').click(function(e){
window.location.href = "/admin/dashboard/jobs";
return false;

});
$('#new-job-post').click(function(e){
    window.location.href = "/admin/dashboard/jobs/new";
    return false;
});
$('#job-offers').click(function(e){
    window.location.href = "/admin/dashboard/job-offers";
    return false;
});

$('#send-issuance').click(function(e){
    window.location.href = "/admin/dashboard/issuance";
    return false;
});

   